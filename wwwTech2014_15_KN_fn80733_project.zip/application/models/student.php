<?php

class Student extends My_Model {
    
}
