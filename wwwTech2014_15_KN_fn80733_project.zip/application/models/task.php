<?php

class Task extends My_Model {
    
}
