<?php

class Course_Controller extends My_Controller {

}