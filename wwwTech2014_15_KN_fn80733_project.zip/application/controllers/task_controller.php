<?php

class Task_Controller extends My_Controller {

}